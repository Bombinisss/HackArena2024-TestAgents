from . import my_agent

def agent():
	return my_agent.FreeRoamingAgent()